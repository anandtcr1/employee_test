﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.Models
{
    public class EmployeeViewModel
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string EmailAddress { get; set; }
        public string Designation { get; set; }
        public List<EmployeeDetailsViewModel> EmployeeDetailsList { get; set; }
    }
}
