﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.Models
{
    public class EmployeeDetailsViewModel
    {
        public int EmployeeDetailsId { get; set; }
        public int EmployeeId { get; set; }
        public string FileTitle { get; set; }
        public string FilePath { get; set; }
        public string FileFullPath { get; set; }
        public IFormFile SelectedFile { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
