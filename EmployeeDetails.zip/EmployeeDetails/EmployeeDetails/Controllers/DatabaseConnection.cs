﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.Controllers
{
    public class DatabaseConnection
    {
        public static string ConnectionString { get; set; }
    }
}
