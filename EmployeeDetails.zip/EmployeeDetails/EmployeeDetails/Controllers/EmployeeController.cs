﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDetails.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeDetails.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IWebHostEnvironment webHostEnvironment;
        public EmployeeController(IWebHostEnvironment hostEnvironment)
        {
            webHostEnvironment = hostEnvironment;
        }

        public IActionResult Index()
        {
            List<EmployeeViewModel> employeeList = new List<EmployeeViewModel>();
            using (SqlConnection con = new SqlConnection(DatabaseConnection.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("GetEmployeeList", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var employee = new EmployeeViewModel();
                    employee.EmployeeId= reader.IsDBNull(reader.GetOrdinal("employee_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("employee_id"));
                    employee.EmployeeName = reader.IsDBNull(reader.GetOrdinal("employee_name")) ? "" : reader.GetString(reader.GetOrdinal("employee_name"));
                    employee.EmailAddress = reader.IsDBNull(reader.GetOrdinal("email_address")) ? "" : reader.GetString(reader.GetOrdinal("email_address"));
                    employee.Designation = reader.IsDBNull(reader.GetOrdinal("designation")) ? "" : reader.GetString(reader.GetOrdinal("designation"));

                    employeeList.Add(employee);
                }
                con.Close();
            }

            return View(employeeList);
        }

        public IActionResult GetEmployee(int employeeId)
        {
            var employee = new EmployeeViewModel();
            using (SqlConnection con = new SqlConnection(DatabaseConnection.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("GetEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("employee_id", employeeId);
                con.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    
                    employee.EmployeeId = reader.IsDBNull(reader.GetOrdinal("employee_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("employee_id"));
                    employee.EmployeeName = reader.IsDBNull(reader.GetOrdinal("employee_name")) ? "" : reader.GetString(reader.GetOrdinal("employee_name"));
                    employee.EmailAddress = reader.IsDBNull(reader.GetOrdinal("email_address")) ? "" : reader.GetString(reader.GetOrdinal("email_address"));
                    employee.Designation = reader.IsDBNull(reader.GetOrdinal("designation")) ? "" : reader.GetString(reader.GetOrdinal("designation"));

                }
                con.Close();
                con.Open();
                cmd = new SqlCommand("GetEmployeeDetailsList", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("employee_id", employeeId);
                SqlDataReader readerDetails = cmd.ExecuteReader();
                while (readerDetails.Read())
                {
                    if (employee.EmployeeDetailsList == null)
                    {
                        employee.EmployeeDetailsList = new List<EmployeeDetailsViewModel>();
                    }
                    EmployeeDetailsViewModel employeeDetails = new EmployeeDetailsViewModel();
                    employeeDetails.EmployeeDetailsId = readerDetails.IsDBNull(readerDetails.GetOrdinal("employee_details_id")) ? 0 : readerDetails.GetInt32(readerDetails.GetOrdinal("employee_details_id"));
                    employeeDetails.EmployeeId = readerDetails.IsDBNull(readerDetails.GetOrdinal("employee_id")) ? 0 : readerDetails.GetInt32(readerDetails.GetOrdinal("employee_id"));
                    employeeDetails.FileTitle = readerDetails.IsDBNull(readerDetails.GetOrdinal("file_title")) ? "" : readerDetails.GetString(readerDetails.GetOrdinal("file_title"));
                    employeeDetails.FilePath = readerDetails.IsDBNull(readerDetails.GetOrdinal("file_path")) ? "" : readerDetails.GetString(readerDetails.GetOrdinal("file_path"));
                    
                    employeeDetails.FileFullPath= Path.Combine(webHostEnvironment.WebRootPath + @"/employee_files", employeeDetails.FilePath);

                    employeeDetails.CreatedDate = readerDetails.IsDBNull(readerDetails.GetOrdinal("created_date")) ? DateTime.Now : readerDetails.GetDateTime(readerDetails.GetOrdinal("created_date"));
                    employee.EmployeeDetailsList.Add(employeeDetails);
                }

                con.Close();
            }
            return View(employee);
        }

        [HttpPost]
        public IActionResult SaveEmployee(EmployeeViewModel employee)
        {
            using (SqlConnection con = new SqlConnection(DatabaseConnection.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("SaveEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                cmd.Parameters.AddWithValue("employee_id", employee.EmployeeId);
                cmd.Parameters.AddWithValue("employee_name", employee.EmployeeName);
                cmd.Parameters.AddWithValue("email_address", employee.EmailAddress);
                cmd.Parameters.AddWithValue("designation", employee.Designation);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult SaveEmployeeDetails(EmployeeDetailsViewModel employeeDetails)
        {
            var uniqueFileName = GetUniqueFileName(employeeDetails.SelectedFile.FileName);
            var filePath = Path.Combine(webHostEnvironment.WebRootPath + @"/employee_files", uniqueFileName);
            using (var stream = System.IO.File.Create(filePath))
            {
                employeeDetails.SelectedFile.CopyTo(stream);
            }

            using (SqlConnection con = new SqlConnection(DatabaseConnection.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("SaveEmployeeDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                cmd.Parameters.AddWithValue("employee_details_id", employeeDetails.EmployeeDetailsId);
                cmd.Parameters.AddWithValue("employee_id", employeeDetails.EmployeeId);
                cmd.Parameters.AddWithValue("file_title", employeeDetails.FileTitle);
                cmd.Parameters.AddWithValue("file_path", uniqueFileName);
                cmd.Parameters.AddWithValue("created_date", DateTime.Now);

                cmd.ExecuteNonQuery();
                con.Close();

                con.Close();
            }

            return RedirectToAction("GetEmployee", new { employeeId = employeeDetails.EmployeeId });
        }

        public IActionResult DeleteEmployee(int employeeId)
        {
            var employee = new EmployeeViewModel();
            using (SqlConnection con = new SqlConnection(DatabaseConnection.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("DeleteEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("employee_id", employeeId);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return RedirectToAction("Index");
        }

        public IActionResult DeleteEmployeeDetails(int employeeDeltailsId, int employeeId)
        {
            var employee = new EmployeeViewModel();
            using (SqlConnection con = new SqlConnection(DatabaseConnection.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("DeleteEmployeeDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("employee_details_id", employeeDeltailsId);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return RedirectToAction("GetEmployee", new { employeeId = employeeId });
        }

        string GetUniqueFileName(string fileName)
        {
            fileName = Path.GetFileName(fileName);
            fileName = fileName.Replace(" ", String.Empty);
            return Path.GetFileNameWithoutExtension(fileName)
                      + "_"
                      + Guid.NewGuid().ToString().Substring(0, 4)
                      + Path.GetExtension(fileName);
        }
    }
}